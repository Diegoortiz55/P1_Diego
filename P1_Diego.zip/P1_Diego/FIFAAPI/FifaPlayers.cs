﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Data.SqlClient;

namespace FIFAAPI
{

    public class FifaPlayers : FifaTeams
    {

        SqlConnection con = new SqlConnection(@"server=localhost;database=fifaDB;user id=sa;password=Strong.Pwd-123");

        #region Get Player Details By Name
        public FifaPlayers GetPlayerByName(string p_playerName)
        {
            SqlCommand cmdGetPlayerByName = new SqlCommand("Select * from Players join Teams on Players.playerTeamId=Teams.teamId where playerName=@playerName", con);
            cmdGetPlayerByName.Parameters.AddWithValue("@playerName", p_playerName);
            SqlDataReader rdpl = null;
            try
            {
                con.Open();
                rdpl = cmdGetPlayerByName.ExecuteReader();
                if (rdpl.Read())
                {
                    FifaPlayers playerDetails = new FifaPlayers()
                    {
                        playerId = Convert.ToInt32(rdpl[0]),
                        playerName = rdpl[1].ToString(),
                        playerPosition = rdpl[2].ToString(),
                        teamId = Convert.ToInt32(rdpl[4]),
                        teamName = rdpl[5].ToString(),
                        teamCountry = rdpl[6].ToString()
                    };
                    return playerDetails;
                }
                else
                {
                    rdpl.Close();
                    con.Close();
                    throw new Exception("Player not found");
                }
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rdpl.Close();
                con.Close();
            }
        }
        #endregion

        #region Get Player Details By Position
        public List<FifaPlayers> GetPlayersByPosition(string p_playerPosition)
        {
            SqlCommand cmdGetPlayersByPosition = new SqlCommand("Select * from Players join Teams on Players.playerTeamId=Teams.teamId where playerPosition=@pPosition", con);
            cmdGetPlayersByPosition.Parameters.AddWithValue("@pPosition", p_playerPosition);
            List<FifaPlayers> positionList = new List<FifaPlayers>();
            SqlDataReader rdplps = null;
            try
            {
                con.Open();
                rdplps = cmdGetPlayersByPosition.ExecuteReader();
                if (rdplps.Read())
                {
                    do
                    {
                        positionList.Add(new FifaPlayers()
                        {
                            playerId = Convert.ToInt32(rdplps[0]),
                            playerName = rdplps[1].ToString(),
                            playerPosition = rdplps[2].ToString(),
                            teamId = Convert.ToInt32(rdplps[4]),
                            teamName = rdplps[5].ToString(),
                            teamCountry = rdplps[6].ToString()
                        });
                    }
                    while (rdplps.Read());
                    return positionList;
                }
                else
                {
                    rdplps.Close();
                    con.Close();
                    throw new Exception("Invalid position");
                }
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rdplps.Close();
                con.Close();
            }
        }
        #endregion

        #region Add New Player
        public string AddNewPlayer(FifaPlayers p_fifaObj)
        {
            SqlCommand cmdAddPlayer = new SqlCommand("if not exists (select playerName from Players where playerName=@playerName) insert into Players values(@playerName,@playerPosition,@playerTeamId)", con);
            cmdAddPlayer.Parameters.AddWithValue("@playerName", p_fifaObj.playerName);
            cmdAddPlayer.Parameters.AddWithValue("@playerPosition", p_fifaObj.playerPosition);
            cmdAddPlayer.Parameters.AddWithValue("@playerTeamId", p_fifaObj.playerTeamId);
            if (string.IsNullOrEmpty(p_fifaObj.playerName))
            {
                throw new Exception("Player name must be provided");
            }
            if (p_fifaObj.playerPosition != "Goalkeeper" && p_fifaObj.playerPosition != "Defender" && p_fifaObj.playerPosition != "Midfielder" && p_fifaObj.playerPosition != "Forward")
            {
                throw new Exception("Invalid player position. Please select a valid position");
            }
            if (p_fifaObj.playerTeamId <= 0)
            {
                throw new Exception("Player's Team Id not valid");
            }
            try
            {
                con.Open();
                int result1 = cmdAddPlayer.ExecuteNonQuery();
                if (result1 == 1)
                {
                    con.Close();
                    return "Player Added";
                }
                    con.Close();
                    throw new Exception("Incorrect entry. Please ensure information is correct");
            }
            catch(Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                con.Close();
            }
        }
        #endregion

        #region Update Player
        public string UpdatePlayer(FifaPlayers p_fifaObj)
        {
            SqlCommand cmdUpdatePlayer = new SqlCommand("update Players set playerTeamId=@playerTeamId where playerName=@playerName", con);
            cmdUpdatePlayer.Parameters.AddWithValue("@playerTeamId", p_fifaObj.playerTeamId);
            cmdUpdatePlayer.Parameters.AddWithValue("@playerName", p_fifaObj.playerName);
            if (p_fifaObj.playerTeamId <= 0)
            {
                throw new Exception("Player's new Team Id not valid");
            } 
            con.Open();
            int result2=cmdUpdatePlayer.ExecuteNonQuery();
            con.Close();
            if (result2 == 1)
            {
                return "Player Updated";
            }
            throw new Exception("Player not found");
        }
        #endregion

        #region Delete Player
        public string DeletePlayer(FifaPlayers p_fifaObj)
        {
            SqlCommand cmdDeletePlayer = new SqlCommand("delete from Players where playerName=@playerName", con);
            cmdDeletePlayer.Parameters.AddWithValue("@playerName", p_fifaObj.playerName);
            con.Open();
            int result3=cmdDeletePlayer.ExecuteNonQuery();
            con.Close();
            if (result3 == 1)
            {
                return "Player Deleted";
            }
            throw new Exception("Player not found");
        }
        #endregion
    }
}

