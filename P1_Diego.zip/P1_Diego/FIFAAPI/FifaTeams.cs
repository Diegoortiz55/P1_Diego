﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Data.SqlClient;

namespace FIFAAPI
{
    public class FifaTeams : IFifaPlayers
    {
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string teamCountry { get; set; }
        private int playerid;
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public int playerId { get => playerid; set => playerid = value; }
        private string playername;
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public string playerName { get=>playername; set=>playername=value; }
        private string playerposition;
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public string playerPosition { get=>playerposition; set=>playerposition=value; }
        private int playerteamid;
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public int playerTeamId { get=>playerteamid; set=>playerteamid=value; }

        SqlConnection con = new SqlConnection(@"server=localhost;database=fifaDB;user id=sa;password=Strong.Pwd-123");

        #region Get All Teams Info
        public List<FifaTeams> GetAllTeamInfo()
        {
            SqlCommand cmdGetAllTeamInfo = new SqlCommand("select * from Teams", con);
            con.Open();
            List<FifaTeams> teamsList = new List<FifaTeams>();
            SqlDataReader rdtms = cmdGetAllTeamInfo.ExecuteReader();
            while (rdtms.Read())
            {
                teamsList.Add(new FifaTeams()
                {
                    teamId = Convert.ToInt32(rdtms[0]),
                    teamName = rdtms[1].ToString(),
                    teamCountry = rdtms[2].ToString()
                });
            }
            rdtms.Close();
            con.Close();
            return teamsList;
        }
        #endregion

        #region Get Team Info by Name
        public List<FifaTeams> GetTeamInfoByName(string p_teamName)
        {
            SqlCommand cmdGetTeamInfo = new SqlCommand("select * from Teams right join Players on Teams.teamId=Players.playerTeamId where teamName=@teamName", con);
            cmdGetTeamInfo.Parameters.AddWithValue("@teamName", p_teamName);
            List<FifaTeams> teamList = new List<FifaTeams>();
            SqlDataReader rdtm = null;
            try
            {
                con.Open();
                rdtm = cmdGetTeamInfo.ExecuteReader();
                if (rdtm.Read())
                {
                    do
                    {
                        teamList.Add(new FifaTeams()
                        {
                            teamId = Convert.ToInt32(rdtm[0]),
                            teamName = rdtm[1].ToString(),
                            teamCountry = rdtm[2].ToString(),
                            playerId = Convert.ToInt32(rdtm[3]),
                            playerName = rdtm[4].ToString(),
                            playerPosition = rdtm[5].ToString()
                        });
                    }
                    while (rdtm.Read());
                    return teamList;
                }
                else
                {
                    rdtm.Close();
                    con.Close();
                    throw new Exception("Team not Found");
                }
            }
            catch (Exception)
            {
                throw new Exception("Team not Found");
            }
            finally
            {
                rdtm.Close();
                con.Close();
            }
        }
        #endregion

        #region Add New Team
        public string AddNewTeam (FifaTeams p_fifaObj)
        {
            SqlCommand cmdAddTeam = new SqlCommand("if not exists (select teamName from Teams where teamName=@teamName) insert into Teams values(@teamName,@teamCountry)", con);
            cmdAddTeam.Parameters.AddWithValue("@teamName", p_fifaObj.teamName);
            cmdAddTeam.Parameters.AddWithValue("@teamCountry", p_fifaObj.teamCountry);
            if (string.IsNullOrEmpty(p_fifaObj.teamName))
            {
                throw new Exception("Team name must be provided");
            }
            if (string.IsNullOrEmpty(p_fifaObj.teamCountry))
            {
                throw new Exception("Team Country must be provided");
            }
            con.Open();
            int result = cmdAddTeam.ExecuteNonQuery();
                if (result == 1)
                {
                    con.Close();
                    return "Team Added";
                }
                else
                {
                    con.Close();
                    throw new Exception("Incorrect entry. Please ensure information is correct");
                }
        }
        #endregion
    }
}

