﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FIFAAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FifaPlayersController : ControllerBase
    {
        FifaPlayers fifaObj = new FifaPlayers();

        #region Get Player Details By Name
        [HttpGet]
       [Route("playerList/name/{playerName}")]
        public IActionResult GetPlayerDetails(string playerName)
        {
            try
            {
                return Ok(fifaObj.GetPlayerByName(playerName));
            }
            catch(Exception ex1)
            {
                return BadRequest(ex1.Message);
            }
        }
        #endregion

        #region Get All Players By Position
        [HttpGet]
        [Route("playerList/position/{playerPosition}")]
        public IActionResult GetPositionDetails(string playerPosition)
        {
            try
            {
                return Ok(fifaObj.GetPlayersByPosition(playerPosition));
            }
            catch(Exception ex2)
            {
                return BadRequest(ex2.Message);
            }
        }
        #endregion

        #region Add New Player
        [HttpPost]
        [Route("playerList/add")]
        public IActionResult AddPlayer(FifaPlayers newPlayer)
        {
            try
            {
                return Ok(fifaObj.AddNewPlayer(newPlayer));
            }
            catch(Exception ex3)
            {
                return BadRequest(ex3.Message);
            }
        }
        #endregion

        #region Update Player
        [HttpPut]
        [Route("playerList/edit")]
        public IActionResult UpdatePlayer(FifaPlayers playerName)
        {
            try
            {
                return Ok(fifaObj.UpdatePlayer(playerName));
            }
            catch(Exception ex4)
            {
                return BadRequest(ex4.Message);
            }
        }
        #endregion

        #region Delete Player
        [HttpDelete]
        [Route("playerList/delete")]
        public IActionResult DeletePlayer(FifaPlayers playerName)
        {
            try
            {
                return Ok(fifaObj.DeletePlayer(playerName));
            }
            catch(Exception ex5)
            {
                return BadRequest(ex5.Message);
            }
        }
        #endregion
    }
}

