﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FIFAAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FifaTeamsController : ControllerBase
    {
        FifaTeams fifaObj = new FifaTeams();

        #region Get All Teams
        [HttpGet]
        [Route("teamList")]
        public IActionResult GetAllTeams()
        {
            return Ok(fifaObj.GetAllTeamInfo());
        }
        #endregion

        #region Get Team Info By Name
        [HttpGet]
        [Route("teamList/{teamName}")]
        public IActionResult GetTeamInfo(string teamName)
        {
            try
            {
                return Ok(fifaObj.GetTeamInfoByName(teamName));
            }
            catch(Exception ex1)
            {
                return BadRequest(ex1.Message);
            }
        }
        #endregion

        #region Add New Team
        [HttpPost]
        [Route("teamsList/add")]
        public IActionResult AddTeam(FifaTeams newTeam)
        {
            try
            {
                return Ok(fifaObj.AddNewTeam(newTeam));
            }
            catch(Exception ex2)
            {
                return BadRequest(ex2.Message);
            }
        }
        #endregion
    }
}

