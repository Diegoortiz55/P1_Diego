﻿using System;

namespace FIFAAPI
{
    public interface IFifaPlayers
    {
        int playerId { get; set; }
        string playerName { get; set; }
        string playerPosition { get; set; }
        int playerTeamId { get; set; }
    }
}

